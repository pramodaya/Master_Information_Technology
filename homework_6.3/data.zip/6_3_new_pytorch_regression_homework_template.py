import os
import pickle
import time
import matplotlib
import sys
import torch
import numpy as np
from torch.hub import download_url_to_file
import matplotlib.pyplot as plt
import torch.utils.data
import torch.nn.functional as F

plt.rcParams["figure.figsize"] = (12, 7) # size of window
plt.style.use('dark_background')

LEARNING_RATE = 1e-3
BATCH_SIZE = 16
TRAIN_TEST_SPLIT = 0.7


class Dataset(torch.utils.data.Dataset):
    def __init__(self):
        super().__init__()
        path_dataset = '../data/cardekho_india_dataset_1_plus_3.pkl'
        if not os.path.exists(path_dataset):
            os.makedirs('../data', exist_ok=True)
            download_url_to_file(
                'http://share.yellowrobot.xyz/quick/2022-10-28-467EF277-AB38-4EA2-8490-A0FCDD7A7CE0.pkl',
                path_dataset,
                progress=True
            )
        with open(f'{path_dataset}', 'rb') as fp:
            self.X, self.Y, self.labels = pickle.load(fp)

        # Labels = [
        #     label_brands, ["BMW", "Audi", ...]
        # ]
        # X = list(zip(
        #     x_brands, [BMW, Audi, ...] => [0, 1 .. ]
        #     x_year, [2000, ..]
        #     x_km_driven, [200_000, .. ]
        #     x_owner [2, .. ]
        # ))

        self.X = np.array(self.X)
        self.X_c = self.X[:, :1]

        self.X = np.array(self.X[:, 1:], dtype=np.float)
        X_mean = np.mean(self.X, axis=0)
        X_std = np.std(self.X, axis=0)
        self.X = (self.X - X_mean) / X_std

        self.Y = np.array(self.Y, dtype=np.float)
        Y_mean = np.mean(self.Y)
        Y_std = np.std(self.Y)
        self.Y = (self.Y - Y_mean) / Y_std

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return (
            torch.FloatTensor(self.X[idx]),
            torch.LongTensor(self.X_c[idx]),
            torch.FloatTensor(np.expand_dims(self.Y[idx], axis=-1))
        )

dataset_full = Dataset()
train_test_split = int(len(dataset_full) * TRAIN_TEST_SPLIT)
dataset_train, dataset_test = torch.utils.data.random_split(
    dataset_full,
    [train_test_split, len(dataset_full) - train_test_split],
    generator=torch.Generator().manual_seed(0)
)

dataloader_train = torch.utils.data.DataLoader(
    dataset=dataset_train,
    batch_size=BATCH_SIZE,
    shuffle=True
)

dataloader_test = torch.utils.data.DataLoader(
    dataset=dataset_test,
    batch_size=BATCH_SIZE,
    shuffle=False
)


class Model(torch.nn.Module):
    def __init__(self):
        super(Model, self).__init__()
        # TODO

    def forward(self, x, x_c):
        # TODO
        y_prim = 0
        return y_prim

class LossHuber(torch.nn.Module):
    def __init__(self):
        super(LossHuber, self).__init__()

    def forward(self, y, y_prim):
        # TODO
        return 0

model = Model()
optimizer = torch.optim.Adam(
    model.parameters(),
    lr=LEARNING_RATE
)
loss_fn = LossHuber()

loss_plot_train = []
loss_plot_test = []
r2_metric_train = []
r2_metric_test = []

for epoch in range(1, 1000):

    for dataloader in [dataloader_train, dataloader_test]:
        losses = []
        r2s = []
        for x, x_c, y in dataloader:

            y_prim = model.forward(x, x_c)
            loss = loss_fn.forward(y_prim, y)

            losses.append(loss.item())
            # TODO: R2
            r2 = 0
            r2s.append(r2)

            if dataloader == dataloader_train:
                loss.backward()
                optimizer.step()
                optimizer.zero_grad()

        if dataloader == dataloader_train:
            loss_plot_train.append(np.mean(losses))
            r2_metric_train.append(np.mean(r2s))
        else:
            loss_plot_test.append(np.mean(losses))
            r2_metric_test.append(np.mean(r2s))

    print(
        f'epoch: {epoch} '
        f'loss_train: {loss_plot_train[-1]} '
        f'loss_test: {loss_plot_test[-1]} '
        f'r2_train: {r2_metric_train[-1]} '
        f'r2_test: {r2_metric_test[-1]} ')

    if epoch % 10 == 0:
        _, axes = plt.subplots(2, 1, figsize=(10, 15))
        for ax1, metrics, title in zip(axes, [
            [loss_plot_train, loss_plot_test],
            [r2_metric_train, r2_metric_test]
        ], ['loss', 'r2']):
            ax1.plot(metrics[0], 'r-', label='train')
            ax2 = ax1.twinx()
            ax2.plot(metrics[1], 'c-', label='test')
            ax1.legend()
            ax2.legend(loc='upper left')
            ax1.set_xlabel("Epoch")
            ax1.set_ylabel(title)
            plt.show()